<template>
    <div id="app">
        <h2>Login</h2>
        <form @submit.prevent="submitForm">
            <div class="mb-3">
                <label for="username" class="form-label">Username: </label>
                <input type="text" id="username" v-model="username" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="password" class="form-label">Password: </label>
                <input type="password" id="password" v-model="password" class="form-control" required>
            </div>

            <button type="button" class="btn btn-success" @click="requestMobileOTP">Get Mobile OTP</button>
            <br>

            <div class="mb-3" v-if="showOTPContainer">
                <br>
                <p>Mobile OTP: {{ mobileOTP }}</p>
                <p>OTP will expires on {{ count }} seconds</p>
                <label for="mobile-otp" class="form-label">Enter OTP: </label>
                <input type="text" id="mobile-otp" v-model="finalOTP" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</template>


<script>

export default {
    name: 'Login',
    data() {
        return {
            username: '',
            password: '',
            mobileOTP: '',
            finalOTP: '',
            showOTPContainer: false,
            count: 15
        }
    },
    methods: {
        requestMobileOTP() {
            // Simulate mobile OTP generation (in a real-world scenario, this should be handled on the server side)
            this.count = 15
            this.mobileOTP = Math.floor(1000 + Math.random() * 9000);
            this.showOTPContainer = true;
            this.startTimer();
        },
        startTimer () {
            const timer = setInterval(() => {
                this.count = this.count - 1

                if (this.count == 0) {
                    clearInterval(timer)
                    this.requestMobileOTP()
                }
            }, 1000);
        },
        submitForm() {
            // Simulate authentication (in a real-world scenario, this should be handled on the server side)
            if (this.username && this.password && this.mobileOTP == this.finalOTP) {
                this.$router.push('/')
            } else {
                alert('Invalid credentials. Please try again.');
            }
        }
    }
}
</script>

<style scoped>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

#app {
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    border-radius: 8px;
    width: 300px;
}

#app h2 {
    text-align: center;
    color: #333;
}

#app form {
    display: flex;
    flex-direction: column;
}

#app label {
    margin-bottom: 8px;
    color: #555;
}

#app input {
    padding: 10px;
    margin-bottom: 16px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

#app button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

#app button:hover {
    background-color: #45a049;
}

#otp-container {
    /* display: none; */
    flex-direction: column;
}
</style>