<template>
    <div id="app">
        <h2>Shopping Cart</h2>

        <div class="product" v-for="product in products" :key="product.id">
            <img :src="getImg(product.image)" alt="Product Image">
            <h3>{{ product.name }}</h3>
            <p>{{ product.description }}</p>
            <p>${{ product.price.toFixed(2) }}</p>
            <button @click="addToCart(product)">Add to Cart</button>
        </div>

        <div id="cart">
            <h2>Shopping Cart</h2>
            <div class="cart-item" v-for="item in cart" :key="item.id">
                <span>{{ item.name }}</span>
                <span>${{ item.price.toFixed(2) }}</span>
            </div>
            <div class="cart-total">
                <span>Total:</span>
                <span>${{ calculateTotal().toFixed(2) }}</span>
            </div>
        </div>

        <div class="billing">
            <button @click="checkout">Checkout</button>
        </div>
    </div>
</template>

<script>

export default {
    name: 'HomeView',
    data() {
        return {
            products: [
                { id: 1, name: 'Product 1', description: 'Description of Product 1.', price: 19.99, image: '1' },
                { id: 2, name: 'Product 2', description: 'Description of Product 2.', price: 29.99, image: '2' },
                // Add more products as needed
            ],
            cart: [],
        }
    },
    methods: {
        getImg (imgNo) {
            return require('@/assets/image'+ imgNo +'.jpeg')
        },
        addToCart(product) {
            this.cart.push({ id: product.id, name: product.name, price: product.price });
        },
        calculateTotal() {
            return this.cart.reduce((total, item) => total + item.price, 0);
        },
        checkout() {
            alert('Checkout successful!\nTotal Amount: $' + this.calculateTotal().toFixed(2));
            // In a real-world scenario, you would send the cart data to the server for processing.
            this.cart = [];
        },
    },
}
</script>


<style scoped>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

#app {
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    border-radius: 8px;
    width: 80%;
}

h2 {
    text-align: center;
    color: #333;
}

.product {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 20px;
}

.product img {
    width: 100%;
    max-width: 200px;
    height: auto;
    border-radius: 8px;
    margin-bottom: 10px;
}

.product button {
    background-color: #4caf50;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.product button:hover {
    background-color: #45a049;
}

#cart {
    margin-top: 20px;
    width: 100%;
}

.cart-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
}

.cart-total {
    display: flex;
    justify-content: space-between;
    font-weight: bold;
    margin-top: 10px;
}

.billing {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 20px;
}

.billing button {
    background-color: #007bff;
    color: #fff;
    padding: 10px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.billing button:hover {
    background-color: #0056b3;
}
</style>
